En este archivo se explica cómo Visual Studio creado el proyecto.

Se usaron las siguientes herramientas para generar este proyecto:
- create-vite

Los pasos siguientes se usaron para generar este proyecto:
- Cree un proyecto de React con create-vite: `npm init --yes vite@latest finanzas.web -- --template=react-ts  --no-rolldown --no-immediate`.
- Actualizando `vite.config.ts` con puerto.
- Crear archivo de proyecto (`finanzas.web.esproj`).
- Crear `launch.json` para habilitar la depuración.
- Agregue el proyecto a la solución.
- Escriba este archivo.
